module.exports = function (grunt) {
	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),
		mvn: require('xml-mapping').load(grunt.file.read("pom.xml")),

		// Java用プロジェクト構成向け設定
		opt: {
			"tsMain": "src/main/typescript",
			"tsMainLib": "src/main/typescript/libs",
			"tsTest": "src/test/typescript",
			"tsTestLib": "src/test/typescript/libs",
			"tsTestResource": "src/test/resources/typescript",
			"scss": "src/main/scss",

			"outBase": "src/main/webapp",
			"jsMainOut": "src/main/webapp/scripts",
			"jsTestOut": "src/test/typescript",
			"cssOut": "src/main/webapp/css",
			"imageOut": "src/main/webapp/images"
		},

		typescript: {
			main: { // --declarations --sourcemap --target ES5 --out client/scripts/main.js client/scripts/main.ts
				src: ['<%= opt.tsMain %>/Ignite.ts'],
				dest: '<%= opt.jsMainOut %>',
				options: {
					target: 'es5',
					base_path: '<%= opt.tsMain %>',
					sourcemap: false,
					declaration_file: false,
					noImplicitAny: false // そのうち有効にしたい
				}
			},
			test: {
				src: ['<%= opt.tsTest %>/IgniteSpec.ts'],
				dest: '<%= opt.tsTest %>/IgniteSpec.js',
				options: {
					target: 'es5',
					sourcemap: false,
					declaration_file: false,
					noImplicitAny: false // そのうち有効にしたい
				}
			}
		},
		tslint: {
			options: {
				formatter: "prose",
				configuration: {
					// https://github.com/palantir/tslint#supported-rules
					"rules": {
						"bitwise": true,
						"classname": true,
						"curly": true,
						"debug": false,
						"dupkey": true,
						"eofline": true,
						"eqeqeq": true,
						"evil": true,
						"forin": false, // TODO 解消方法よくわからない
						// "indent": [false, 4], // WebStormのFormatterと相性が悪い
						"labelpos": true,
						"label-undefined": true,
						// "maxlen": [false, 140],
						"noarg": true,
						"noconsole": [false,
							"debug",
							"info",
							"time",
							"timeEnd",
							"trace"
						],
						"noconstruct": true,
						"nounreachable": false, // switchに警告出してくるので…
						"noempty": false, // プロパティアクセス付き引数有りのコンストラクタまで怒られるので
						"oneline": [true,
							"check-open-brace",
							"check-catch",
							"check-else",
							"check-whitespace"
						],
						"quotemark": [true, "double"],
						"radix": false, // 10の基数指定するのめんどいので
						"semicolon": true,
						"sub": true,
						"trailing": true,
						"varname": false, // _hoge とかが許可されなくなるので…
						"whitespace": [false, // WebStormのFormatterと相性が悪い
							"check-branch",
							"check-decl",
							"check-operator",
							"check-separator" ,
							"check-type"
						]
					}
				}
			},
			files: {
				src: ['<%= opt.tsMain %>/**/*.ts', '<%= opt.tsTest %>/**/*.ts'],
				filter: function (filepath) {
					var mainLib = grunt.config.get("opt.tsMainLib") + "/";
					var testLib = grunt.config.get("opt.tsTestLib") + "/";
					if (filepath.indexOf(mainLib) !== -1 || filepath.indexOf(testLib) !== -1) {
						return false;
					}

					return true;
				}
			}
		},
		compass: {
			dev: {
				options: {
					sassDir: '<%= opt.scss %>',
					cssDir: '<%= opt.cssOut %>',
					imagesDir: '<%= opt.imageOut %>',
					javascriptsDir: '<%= opt.jsMainOut %>',
					noLineComments: false,
					debugInfo: true,
					relativeAssets: true
				}
			},
			prod: {
				options: {
					environment: 'production',
					sassDir: '<%= opt.scss %>',
					cssDir: '<%= opt.cssOut %>',
					imagesDir: '<%= opt.imageOut %>',
					javascriptsDir: '<%= opt.jsMainOut %>',
					noLineComments: true,
					debugInfo: false,
					relativeAssets: true
				}
			}
		},
		watch: {
			"typescript-main": {
				files: ['<%= opt.tsMain %>/**/*.ts'],
				tasks: ['typescript:main']
			},
			"typescript-test": {
				files: [ '<%= opt.tsTest %>/**/*.ts'],
				tasks: ['typescript']
			},
			compass: {
				files: ['<%= opt.scss %>/**/*.scss'],
				tasks: ['compass:dev']
			},
			// mvn appengine:devserver と組み合わせた時用
			devserver: {
				files: ['<%= opt.outBase %>/**/*'],
				// tasks: ['devserver'] // なぜかtypescript周りがエラー出すので
				tasks: ['compass:dev', 'copy:devserver']
			}
		},
		concat: {
			test: {
				src: [
					'<%= opt.tsTestResource %>/testdata-header.js.template',
					'<%= opt.tsTestResource %>/data/*.js',
					'<%= opt.tsTestResource %>/testdata-footer.js.template'
				],
				dest: '<%= opt.tsTest %>/testdata.js'
			}
		},
		bower: {
			install: {
				options: {
					targetDir: 'bower-task',
					layout: 'byType', // exportsOverride の左辺に従って分類
					install: true,
					verbose: true, // ログの詳細を出すかどうか
					cleanTargetDir: true,
					cleanBowerDir: false
				}
			}
		},
		copy: {
			bower: {
				files: [
					{
						expand: true,
						flatten: true,
						cwd: 'bower-task/',
						src: ['main-js/**/*.js'],
						dest: '<%= opt.jsMainOut %>/libs/'
					},
					{
						expand: true,
						flatten: true,
						cwd: 'bower-task/',
						src: ['main-css/**/*.css'],
						dest: '<%= opt.cssOut %>/'
					},

					{
						expand: true,
						flatten: true,
						cwd: 'bower-task/',
						src: ['test-js/**/*.js', 'test-css/**/*.css'],
						dest: '<%= opt.tsTest %>/libs/'
					}
				]
			},
			tsd: {
				files: [
					{
						expand: true,
						cwd: 'd.ts/DefinitelyTyped/',
						src: ['*/*.d.ts'],
						dest: '<%= opt.tsMain %>/libs/DefinitelyTyped/'
					},
					{
						expand: true,
						cwd: 'd.ts/DefinitelyTyped/',
						src: ['*/*.d.ts'],
						dest: '<%= opt.tsTest %>/libs/DefinitelyTyped/'
					}
				]
			},
			// mvn appengine:devserver と組み合わせた時用
			devserver: {
				files: [
					{
						expand: true,
						cwd: '<%= opt.outBase %>',
						src: ['**/*'],
						dest: 'target/<%= mvn.project.artifactId.$t %>-<%= mvn.project.version.$t %>/'
					}
				]
			}
		},
		uglify: {
			dev: {
				options: {
					report: 'min',
					// 変数名の圧縮類は作業コストが大きすぎるのでやらない
					mangle: false,
					preserveComments: 'some',

					sourceMap: 'src/main/webapp/scripts/source.js.map',
					sourceMapRoot: '',
					sourceMappingURL: 'source.js.map'
				},
				files: {
					'src/main/webapp/scripts/main.min.js': [
						'<%= opt.jsMainOut %>/libs/*.js',
						'<%= opt.jsMainOut %>/controller/*.js',
						'<%= opt.jsMainOut %>/service/*.js',
						'<%= opt.jsMainOut %>/*.js'
					]
				}
			},
			prod: {
				options: {
					report: 'gzip',
					// 変数名の圧縮類は作業コストが大きすぎるのでやらない
					mangle: false,
					preserveComments: 'some'
				},
				files: {
					'src/main/webapp/scripts/main.min.js': [
						'<%= opt.jsMainOut %>/libs/jquery/jquery.js',
						'<%= opt.jsMainOut %>/libs/angular/angular.js',
						'<%= opt.jsMainOut %>/controller/*.js',
						'<%= opt.jsMainOut %>/service/*.js',
						'<%= opt.jsMainOut %>/*.js'
					]
				}
			}
		},
		replace: {
			sourceMap: {
				src: ['<%= opt.jsMainOut %>/source.js.map'],
				overwrite: true,
				replacements: [
					{
						from: "<%= opt.jsMainOut %>/",
						to: ""
					}
				]
			},
			adhocFix: {
				src: ['<%= opt.tsTest %>/libs/DefinitelyTyped/angularjs/angular-mocks.d.ts'],
				overwrite: true,
				replacements: [
					{ // 本体コード側の定義と重複読み込みして困るので
						from: '/// <reference path="angular.d.ts" />',
						to: ""
					}
				]
			}
		},
		clean: {
			clientCss: {
				src: [
					'<%= opt.cssOut %>/*.css'
				]
			},
			clientScript: {
				src: [
					// client
					'<%= opt.jsMainOut %>/*.js',
					'<%= opt.jsMainOut %>/*.d.ts',
					'<%= opt.jsMainOut %>/*.js.map',
					'<%= opt.jsMainOut %>/service',
					'<%= opt.jsMainOut %>/controller',
					// client test
					'<%= opt.jsTestOut %>/*.js',
					'<%= opt.jsTestOut %>/*.js.map',
					'<%= opt.jsTestOut %>/*.d.ts',
					// minified
					'<%= opt.jsMainOut %>/main.min.js',
					'<%= opt.jsMainOut %>/source.js.map'
				]
			},
			tsd: {
				src: [
					// tsd installed
					'<%= opt.tsMain %>/libs/DefinitelyTyped',
					'<%= opt.tsTest %>/libs/DefinitelyTyped'
				]
			},
			bower: {
				src: [
					// bower installed
					'<%= opt.jsMainOut %>/libs',
					'<%= opt.jsTestOut %>/libs/*.js',
					'<%= opt.tsTestMain %>/libs/*.css'
				]
			}
		},
		karma: {
			unit: {
				options: {
					configFile: 'karma.conf.js',
					autoWatch: false,
					browsers: ['PhantomJS'],
					reporters: ['progress', 'junit'],
					singleRun: true,
					keepalive: true
				}
			}
		},
		open: {
			"test-browser": {
				path: '<%= opt.tsTest %>/SpecRunner.html'
			}
		},
		exec: {
			tsd: {
				cmd: function () {
					return "tsd install jquery angular jasmine angular-mocks";
				}
			}
		}
	});

	grunt.registerTask(
		'setup',
		"プロジェクトの初期セットアップを行う。",
		['clean', 'bower', 'exec:tsd', 'copy', 'replace:adhocFix']);

	grunt.registerTask(
		'default',
		"必要なコンパイルを行い画面表示できるようにする。",
		['clean:clientCss', 'clean:clientScript', 'typescript:main', 'tslint', 'compass:dev', 'uglify:dev', 'replace:sourceMap']);

	grunt.registerTask(
		'devserver',
		"mvn appengine:devserver を実行するための前処理を行う",
		['default', 'copy:devserver']);

	grunt.registerTask(
		'prod',
		"デプロイ用の環境を整える",
		['clean:clientCss', 'clean:clientScript', 'typescript:main', 'tslint', 'compass:dev', 'uglify:prod']);

	grunt.registerTask(
		'test',
		"必要なコンパイルを行いkarma(旧testacular)でテストを実行する。",
		['clean:clientScript', 'concat', 'typescript:test', 'tslint', 'karma']);
	grunt.registerTask(
		'test-browser',
		"必要なコンパイルを行いブラウザ上でテストを実行する。",
		['clean:clientScript', 'concat', 'typescript', 'tslint', 'uglify:dev', 'open:test-browser']);

	require('matchdep').filterDev('grunt-*').forEach(grunt.loadNpmTasks);
};
