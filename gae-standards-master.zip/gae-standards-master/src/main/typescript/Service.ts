///<reference path='libs/DefinitelyTyped/angularjs/angular.d.ts' />

///<reference path='Model.ts' />
///<reference path='Controller.ts' />

///<reference path='service/SampleServiceModule.ts' />
