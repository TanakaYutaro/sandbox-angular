///<reference path='controller/SampleControllerModuleSpec.ts' />
