///<reference path='libs/DefinitelyTyped/jasmine/jasmine.d.ts' />

///<reference path='../../main/typescript/libs/DefinitelyTyped/angularjs/angular.d.ts' />
///<reference path='libs/DefinitelyTyped/angularjs/angular-mocks.d.ts' />

///<reference path='../../main/typescript/Model.ts' />

"use strict";

describe("Modelの", ()=> {
});
