///<reference path='libs/DefinitelyTyped/jasmine/jasmine.d.ts' />

///<reference path='../../main/typescript/libs/DefinitelyTyped/angularjs/angular.d.ts' />
///<reference path='libs/DefinitelyTyped/angularjs/angular-mocks.d.ts' />

///<reference path='../../main/typescript/Service.ts' />

///<reference path='service/SampleServiceModuleSpec.ts' />

((global:any)=> {
})(window);
