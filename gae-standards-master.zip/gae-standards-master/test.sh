#!/bin/sh
ISERROR=0

which mvn > /dev/null 2>&1
if [ $? -ne 0 ] ; then
	echo "command not found: mvn"
	echo "please install mvn. e.g. sudo port install maven3"
	ISERROR=1
fi

which grunt > /dev/null 2>&1
if [ $? -ne 0 ] ; then
	echo "command not found: grunt"
	echo "please install grunt. e.g. npm install -g grunt-cli , and exec ./setup.sh"
	ISERROR=1
fi

mvn clean test && \
grunt test && \
echo "OK!"
